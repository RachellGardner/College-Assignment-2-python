#Преобразуйте число в строку!https://www.codewars.com/kata/5265326f5fda8eb1160004c8/solutions/python
def number_to_string(num):
    return str(num)