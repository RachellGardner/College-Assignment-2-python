#Возвращаемые строки,https://www.codewars.com/kata/55a70521798b14d4750000a4/solutions/python
def greet(name):
    return "Hello, " + name + " how are you doing today?"
