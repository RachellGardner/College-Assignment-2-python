# Площадь или Периметр,https://www.codewars.com/kata/5ab6538b379d20ad880000ab/train/python
def area_or_perimeter(length, width):
    
    if length == width:
        return length * width  
    else:
        return 2 * (length + width) 