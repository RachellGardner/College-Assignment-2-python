st = list(str(input()))
if st == st [::-1]:
    print("палиндром")
else:
    print("не палиндром")
