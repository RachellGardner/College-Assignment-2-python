questions = [
    {"question": "Куда лучше всего прийти на маник?", "answer": "к Кате"},
    {"question": "А сколько стоит маникюр у Кати?", "answer": "1500"},
    {"question": "А где ты получишь ногти под ледибаг?", "answer": "только у Кати"},
    {"question": "Катя+маник = ", "answer": "любовь"}
]

correct_answers = 0

for q in questions:
    print(q["question"]) 
    user_answer = input("Ну и что ты натыкал: ")  
    
    if user_answer.lower() == q["answer"].lower():
        print("Оу ес!\n")
        correct_answers += 1
    else:
        print(f"Ты че,а не че то, что  правильный ответ: {q['answer']}\n")
print(f"Фух! Ты ответил правильно на {correct_answers} из {len(questions)} вопросов.")