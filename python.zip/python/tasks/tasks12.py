string = input("Введите строку: ")
start_char = input("Введите начальный символ: ")
end_char = input("Введите конечный символ: ")


start_index = string.index(start_char)  
end_index = string.index(end_char, start_index + 1) 

print (string[start_index + 1: end_index])