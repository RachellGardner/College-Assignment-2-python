number = input("Ввидите треззначное число")
sotni = number[0]
desytki = number[1]
ones = number[2]
print(f"Сотни {sotni} Десятки {desytki} Единицы {ones}")